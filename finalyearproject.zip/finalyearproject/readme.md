install database 
pip install mysqlclient



